<?php
session_start();

function isAdmin() {
    // Assuming the admin has user ID 1
    if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == 1 && $_SESSION['userid'] == 1) {
        return true;
    }
    return false;
}

function checkUser() {
    if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == 1) {
        return true;
    } else {
        $_SESSION['URI'] = 'http://localhost' . $_SERVER['REQUEST_URI']; // save current URL for redirect
        header('Location: http://localhost/bnb/login.php', true, 303);
        exit;
    }
}

function loginStatus() {
    if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == 1) {
        $un = $_SESSION['username'];
        echo "<h2>Logged in as $un</h2>";
    } else {
        echo "<h2>Logged out</h2>";
    }
}

function login($id, $username) {
    $_SESSION['loggedin'] = 1;
    $_SESSION['userid'] = $id;
    $_SESSION['username'] = $username;

    $uri = isset($_SESSION['URI']) && !empty($_SESSION['URI']) ? $_SESSION['URI'] : 'http://localhost/bnb/listcustomers.php';
    $_SESSION['URI'] = ''; 
    header('Location: ' . $uri, true, 303);
    exit;
}

function logout() {
    session_destroy();
    header('Location: http://localhost/bnb/login.php', true, 303);
    exit;
}
?>
