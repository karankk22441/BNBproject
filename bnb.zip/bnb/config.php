<?php
//MySQL credentails
define("DBUSER","root");
define("DBPASSWORD","");
define("DBDATABASE","bnb");
?>