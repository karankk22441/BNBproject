<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .login-container {
            width: 300px;
            margin: 0 auto;
            padding-top: 100px;
        }
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }
        input[type="text"], input[type="password"] {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
        }
        input[type="submit"] {
            padding: 8px 16px;
            margin-right: 10px;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h1>User Login</h1>
        <form method="POST" action="">
            <p>
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" required>
            </p>
            <p>
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
            </p>
            <p>
                <input type="submit" name="login" value="Login">
            </p>
        </form>
    </div>

    <?php
    
   
    include "checksession.php"; 
    include "config.php"; 

    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['login'])) {
        // Connect to the database
        $DBC = mysqli_connect("127.0.0.1", DBUSER, DBPASSWORD, DBDATABASE);

        if (!$DBC) {
            die("Error: Unable to connect to MySQL. " . mysqli_connect_error());
        }

       
        $username = mysqli_real_escape_string($DBC, trim($_POST['username']));
        $password = mysqli_real_escape_string($DBC, trim($_POST['password']));

     
        $query = "SELECT id, password FROM users WHERE username = ?";
        $stmt = mysqli_prepare($DBC, $query);
        mysqli_stmt_bind_param($stmt, 's', $username);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_store_result($stmt);

        
        if (mysqli_stmt_num_rows($stmt) == 1) {
            mysqli_stmt_bind_result($stmt, $userID, $stored_password);
            mysqli_stmt_fetch($stmt);

            if ($password === $stored_password) {
              
                login($userID, $username);
            } else {
                echo "<p>Incorrect password. Please try again.</p>";
            }
        } else {
            echo "<p>Username not found. Please try again.</p>";
        }

    
        mysqli_stmt_close($stmt);
        mysqli_close($DBC);
    }
    ?>
</body>
</html>
